package com.project.dbconnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	private String username="root";
	private String password="!QAZ2wsx";
	private String path="jdbc:mysql://localhost:3306/world";
	private String driver="org.gjt.mm.mysql.Driver";
	private Connection connection=null;
	
	public Connection getConnection() {
		return connection;
	}

	public DBConnection(){
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(path, username, password);
			System.out.println("OK");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
