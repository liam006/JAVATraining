package com.project.userdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.project.dbconnection.DBConnection;

public class UserDao implements userDaoInterface {

	@Override
	public boolean insertUser(UserBean user) {
		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		boolean returnValue = false;
		
		try {
			preStmt = connection.prepareStatement("insert into user(name, sex, age, password, type) values(?,?,?,?,?)");
			preStmt.setString(1, user.getName());
			preStmt.setString(2, user.getSex());
			preStmt.setString(3, user.getAge());
			preStmt.setString(4, user.getPassword());
			preStmt.setString(5, user.getType());
			preStmt.executeUpdate();
			
			returnValue = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			 try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
			 try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		
		return returnValue;
	}

	public boolean deleteUserById(String id) {
		
		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		boolean returnValue = false;
		
		try {
			preStmt = connection.prepareStatement("delete from user where id=?");
			preStmt.setString(1, id);
			preStmt.executeUpdate();
			
			returnValue = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			 try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
			 try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		
		return returnValue;
	}
	
	@Override
	public boolean getUser(int id) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public UserBean getUserById(String id) {

		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		ResultSet rs = null;
		UserBean user = new UserBean();
		
		try {
			preStmt = connection.prepareStatement("select * from user where id=?");
			preStmt.setString(1, id);
			rs = preStmt.executeQuery();
			if (rs.next()) {
				user.setId(rs.getString("id"));
				user.setAge(rs.getString("age"));
				user.setName(rs.getString("name"));
				user.setSex(rs.getString("sex"));
				user.setPassword(rs.getString("password"));
				user.setType(rs.getString("type"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			 try { if (rs != null) rs.close(); } catch (Exception e) {};
			 try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
			 try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		
		return user;
	}
	
	public boolean updateUser(UserBean user) {

		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		
		try {
			preStmt = connection.prepareStatement("update user set name=?, sex=?, age=?, password=?, type=? where id=?");
			preStmt.setString(1, user.getName());
			preStmt.setString(2, user.getSex());
			preStmt.setString(3, user.getAge());
			preStmt.setString(4, user.getPassword());
			preStmt.setString(5, user.getType());
			preStmt.setString(6, user.getId());
			preStmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			 try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
			 try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		
		return false;
	}
	
	public UserBean getUserByName(String name) {
		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		ResultSet rs = null;
		UserBean bean = new UserBean();
		
		try {
			preStmt = connection.prepareStatement("select * from user where name=?");
			preStmt.setString(1, name);
			rs = preStmt.executeQuery();
			if (rs.next()) {
				bean.setId(rs.getString("id"));
				bean.setAge(rs.getString("age"));
				bean.setName(rs.getString("name"));
				bean.setSex(rs.getString("sex"));
				bean.setPassword(rs.getString("password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			 try { if (rs != null) rs.close(); } catch (Exception e) {};
			 try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
			 try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		return bean;
	}

	public ArrayList<UserBean> getAllUsers() {

		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		ResultSet rs = null;
		
		ArrayList userList = new ArrayList<UserBean>();
		
		try {
			preStmt = connection.prepareStatement("select * from user");
			rs = preStmt.executeQuery();
			while (rs.next()) {
				UserBean bean = new UserBean();
				bean.setId(rs.getString("id"));
				bean.setAge(rs.getString("age"));
				bean.setName(rs.getString("name"));
				bean.setSex(rs.getString("sex"));
				bean.setPassword(rs.getString("password"));
				bean.setType(rs.getString("type"));
				userList.add(bean);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			 try { if (rs != null) rs.close(); } catch (Exception e) {};
			 try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
			 try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		
		return userList;

	}
	
	@Override
	public boolean verifyUser(String name, String password) {

		boolean returnValue = false;
		Connection connection = new DBConnection().getConnection();
		PreparedStatement preStmt = null;
		ResultSet rs = null;
		
		try {
			preStmt = connection.prepareStatement("select * from user where name=? and password=?");
			preStmt.setString(1, name);
			preStmt.setString(2, password);
			
			rs = preStmt.executeQuery();
			if (rs.next()) {
				returnValue = true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
		    try { if (rs != null) rs.close(); } catch (Exception e) {};
		    try { if (preStmt != null) preStmt.close(); } catch (Exception e) {};
		    try { if (connection != null) connection.close(); } catch (Exception e) {};
		}
		
		return returnValue;
	}

}
