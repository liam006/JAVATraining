package com.project.userdao;

public interface userDaoInterface {

	public boolean insertUser(UserBean user);
	
	public boolean getUser(int id);
	
	public boolean verifyUser(String name, String password);
}
