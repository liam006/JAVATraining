package com.project.login;

import com.project.userdao.UserDao;
import com.project.userdao.userDaoInterface;

public class VerifyUser {
	
	public boolean verifyUser(String username, String password){
		userDaoInterface dao = new UserDao();
		if (dao.verifyUser(username, password)) {
			return true;
		}
		return false;
	}

}
